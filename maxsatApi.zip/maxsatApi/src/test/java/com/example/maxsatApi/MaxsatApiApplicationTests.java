package com.example.maxsatApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaxsatApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
